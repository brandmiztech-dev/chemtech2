CHEMTECH homepage image assets

The supplied HTML references these existing remotely hosted images. They are intentionally left as their original URLs in index.html and js/main.js to preserve the current appearance and avoid replacing them with different images.

https://chemtech-online.com/wp-content/uploads/2026/04/Jasubhai-Shah-300x300-1.jpg
https://chemtech-online.com/wp-content/uploads/2026/04/WhatsApp-Image-2026-04-23-at-11.08.23-AM.jpeg
https://chemtech-online.com/wp-content/uploads/2026/04/chemtechlogo-spectrum.png
https://chemtech-online.com/wp-content/uploads/2026/05/chemtech-2026-logo.png
https://chemtech-online.com/wp-content/uploads/2026/05/specialty-2026-logo.png
https://chemtech-online.com/wp-content/uploads/2026/06/443D36F5-46B5-4172-8269-F504368522FC.png
https://chemtech-online.com/wp-content/uploads/2026/06/A92DC92A-22C1-4F5B-AFF0-7E81B4130111.png
https://chemtech-online.com/wp-content/uploads/2026/06/CC8F8155-554C-44C6-BE45-5685CED41CA0.png
https://chemtech-online.com/wp-content/uploads/2026/06/ChatGPT-Image-Jun-29-2026-05_44_21-PM.png
https://chemtech-online.com/wp-content/uploads/2026/06/ChatGPT-Image-Jun-29-2026-05_48_29-PM.png
https://chemtech-online.com/wp-content/uploads/2026/06/D1CD7BAE-BABD-48DB-8249-4E80B59C68DF.png
https://chemtech-online.com/wp-content/uploads/2026/06/E42BBF25-B17A-4B4F-BFD6-F8BB46FE8A15.png
https://chemtech-online.com/wp-content/uploads/2026/07/3-1.png
https://images.unsplash.com/photo-1504917595217-d4dc5ebe6122?auto=format&fit=crop&w=700&q=80
https://images.unsplash.com/photo-1513828583688-c52646db42da?auto=format&fit=crop&w=1400&q=80
https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=800&q=80
https://images.unsplash.com/photo-1540575467063-178a50c2df87?auto=format&fit=crop&w=1200&q=80
https://saddlebrown-toad-686254.hostingersite.com/wp-content/uploads/2026/07/ChatGPT-Image-Jun-12-2026-02_37_53-PM-1024x486.png
https://saddlebrown-toad-686254.hostingersite.com/wp-content/uploads/2026/08/caf04542-44aa-4c92-a0ea-1788dcd45995.png
