/* =========================================================
   SITE CONFIGURATION — set destinations & replaceable assets here.
   Empty values are handled gracefully (no invented URLs): the button
   shows a "coming soon" notice instead of pretending to work.
   ========================================================= */
const SITE_CONFIG = {
  brochureUrl: '',          // Download Brochure — NOT SUPPLIED
  reportUrl: '',            // View Post Event Report — NOT SUPPLIED
  studentOutreachUrl: '',   // Student Outreach — CLICK HERE — NOT SUPPLIED
  scaleUrl: '',             // Visit SCALE Climate Tech Expo — NOT SUPPLIED
  registerUrl: '',          // Register to Visit — NOT SUPPLIED
  bookStandUrl: '',         // Book a Stand — NOT SUPPLIED
  floorPlanUrl: '',         // View Floor Plan — NOT SUPPLIED
  intlSalesUrl: '',         // International Sales Opportunities — NOT SUPPLIED
  jasubhaiMediaUrl: '',     // Jasubhai Media site — NOT SUPPLIED
  /* Hero banner: replaceable sample images (swap for the final banner) */
  heroBanner: 'https://images.unsplash.com/photo-1513828583688-c52646db42da?auto=format&fit=crop&w=1400&q=80',
  heroSecond: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=800&q=80',
  contact: {                // Jasubhai Group postal address / phone / email — NOT SUPPLIED
    address: '',
    phone: '',
    email: ''
  }
};

/* CHEMTECH Luminaries 2026 — all 22 names as supplied.
   Portrait URLs, designations and committee roles were NOT in the content file:
   add them as { photo:'https://…', designation:'…', role:'…' } and they render automatically. */
const LUMINARIES = [
  'Dr R. A. Mashelkar','Mr B. Narayan','Mr Saumitra Priya Srivastava','Prof. (Dr.) Aniruddha B. Pandit',
  'Shri S. C. Mudgerikar','Mr Rajeev Mathur','Dr Rajesh Gokhale','Mr Subramanian Sarma','Mr Anil V. Parab',
  'Mr Rajendra Gogri','Mr Mirik Gogri','Shri S. Masood Husain','Mr R. Mukundan','Dr Alok Sharma',
  'Mr Rajiv Agarwal','Dr Raman Ramachandran','Mr Ajay Popat','Dr Siba Prasad Mohanty','Mr Pankaj Kumar',
  'Dr Arup Kumar Misra','Mr U. K. Bhattacharya','Mr R. K. Srivastava'
].map(name=>({name,photo:'',designation:'',role:''}));

/* 2026 inaugural sessions — titles supplied. Photos/captions/dates were NOT in the content file
   except the EPC inaugural-session photo. Add { img, date, caption } to each entry as supplied. */
const CONFERENCES = [
  {t:'Health, Safety & Environment Conference',tag:'HSE'},
  {t:'Engineering, Procurement & Construction Conference',tag:'EPC',img:'https://chemtech-online.com/wp-content/uploads/2026/06/D1CD7BAE-BABD-48DB-8249-4E80B59C68DF.png',alt:'EPC Conference — inaugural session'},
  {t:'BioX India Conference',tag:'BioX'},
  {t:'Agrochemicals & Fertilizers Conference',tag:'Agro'},
  {t:'WaterEX Conference',tag:'WaterEX'},
  {t:'Surface Engineering Conference',tag:'Surface'},
  {t:'Refining & Petrochemicals Conference',tag:'R&P'},
  {t:'IAC + PVF Conference',tag:'IAC+PVF'}
].map(c=>Object.assign({img:'',date:'',caption:'',alt:''},c));

/* International pavilions — names supplied; image URLs NOT supplied (add `img`). */
const PAVILIONS = [
  {t:'Indo-German Pavilion',img:'',flag:['#FF9933','#ffffff','#138808','#000000','#DD0000','#FFCE00']},
  {t:'Russian Pavilion',img:'',flag:['#ffffff','#0039A6','#D52B1E']},
  {t:'UK Pavilion',img:'',flag:['#012169','#ffffff','#C8102E']}
];

/* Testimonials — none supplied. { quote:'', name:'', designation:'', organisation:'' } */
const TESTIMONIALS = [];

/* CHEMTECH Journey — all 19 supplied milestones, wording preserved
   (including the supplied 1984 / 1987 / 1995 descriptions, which look inconsistent — flagged, not corrected). */
const JOURNEY = [
  {year:'1974',title:'Pioneers Trade Fair',text:'CHEMTECH starts the first international trade fair in India with Chemtech ’74 International Exhibition & Conference.'},
  {year:'1980',title:'Computers and Biotech',text:'Promotes usage of new technology with focus on Computer Application in Chemical Process Industries and Biotechnology.'},
  {year:'1981',title:'Takes Indian Industry International',text:'Sends the Chemtech Industry Mission to USA at ‘Offshore Technology Conference OTC ’81, Houston.'},
  {year:'1984',title:'Turns Focus to Environmental Protection',text:'Showcases new technologies to optimize Indian agricultural production and the Food Processing and Beverage Industry.'},
  {year:'1987',title:'Focuses on Hydrocarbon & Energy Sectors',text:'Hosts the ‘Envirotech 84’ – India’s first Exhibition and Conference on Environmental Protection.'},
  {year:'1995',title:'Technology & Agriculture',text:'Showcases new technologies to optimize Indian agricultural production and the Food Processing and Beverage Industry.'},
  {year:'2000',title:'Continued International Presence',text:'Completes 20 years of association with ACHEMA. Hosts the largest ‘India Day Function’ in Frankfurt with more than 600 visitors from 31 countries.'},
  {year:'2004',title:'Oceantex Awards',text:'First year of the Oceantex Leadership and Excellence Award.'},
  {year:'2009',title:'Expands Scope, Adds New Verticals',text:'EPC, Water, and Industrial Automation focused technology platforms.'},
  {year:'2010',title:'Launches Enertech World Expo',text:'India’s first ever international platform for renewable energy.'},
  {year:'2011',title:'New Initiatives',text:'Introduces Refining & Petrochemicals conferences, International Partnership Program, SME Matchmaking, and Student Outreach.'},
  {year:'2015',title:'Specialty Chemicals',text:'Adds a technical platform for Specialty Chemicals.'},
  {year:'2016',title:'Expands Scope of Energy Platform',text:'Launches technical verticals for Nuclear Energy & Gas Technologies.'},
  {year:'2017',title:'Deepens Energy Platform',text:'Continues expansion of Nuclear Energy & Gas Technology verticals.'},
  {year:'2018',title:'Inland Waterways & Ports',text:'Adds the Forum for Infrastructure & Logistics.'},
  {year:'2019',title:'Chlor Alkali',text:'Organizes the Chlor Alkali Forum and Lab Analytixs.'},
  {year:'2020',title:'Integrated Energy Event',text:'Successfully organizes the Integrated Energy Event – Oil, Gas & Power.',image:'https://chemtech-online.com/wp-content/uploads/2026/06/ChatGPT-Image-Jun-29-2026-05_48_29-PM.png',imageAlt:'Oil, Gas & Power — Integrated Energy'},
  {year:'2021',title:'Online Exhibition',text:'Successfully organizes ChemTECH IE and Oil Gas & Power IE as an online exhibition.'},
  {year:'2024',title:'Chemtech 50 Years',text:'Celebrating the Golden Jubilee of Chemtech World Expo.',gold:true}
];

const BASE = 'https://saddlebrown-toad-686254.hostingersite.com/wp-content/uploads/2026/08/';
const LOGOS = [
  ['Pumps, Valves and Fittings','Pumps-Valves-and-fittings-world-expo-2028.png'],
  ['Refining & Petrochemicals','Refining-Petro-chemicals-2028.png'],
  ['SCALE CHEMTECH','Scale-Chemtech-2028.png'],
  ['Specialty Chemicals','Specialty-chemicals-world-expo-2028.png'],
  ['Student Outreach Program','Student-Outreach-Program-Wrold-Expo-2028.png'],
  ['Surface Engineering, Coating & Corrosion','Surface-Engineering-Coating-Corrosion-world-expo-2028.png'],
  ['Water EX','Water-EX-world-Expo.png'],
  ['Agrochemicals & Fertilizers','Agrochemicals-and-fertilizers-innovation-and-RND-world-expo-2028.png'],
  ['Bio Pharma','Bio-Pharma-world-expo-2028.png'],
  ['Boiler World Expo','Boiler-World-expo-2028.png'],
  ['Chlor-','Chlor-.png'],
  ['Engineering, Procurement & Construction','Engineering-pocurement-and-construction-world-expo-2028.png'],
  ['Health, Safety & Environment','Health-Safty-Environment-world-expo-2028.png'],
  ['Industry Automation & Control','Industry-automation-and-control-world-expo-2028.png'],
  ['Lab Analytix','Lab-analytix-world-expo-2028.png']
].map(([name,file])=>({name,src:BASE+file}));

const NAV = [
  {label:'Home',href:'#home'},
  {label:'Exhibitions',href:'#exhibitions'},
  {label:'Conferences',href:'#conferences',children:[{label:'Speakers',href:'#speakers'},{label:'Conference Program',href:'#program'}]},
  {label:'Advisory Board',href:'#advisory'},
  {label:'Exhibitors',href:'#exhibitors',children:[{label:'Who Exhibits',href:'#exhibitors'},{label:'Why Exhibit',href:'#highlights'},{label:'View Floor Plan',href:'#',cta:'floorPlanUrl'},{label:'International Sales Opportunities',href:'#international'}]},
  {label:'Visitors',href:'#visitors',children:[{label:'Who Visits',href:'#visitors'},{label:'Why Visit',href:'#highlights'}]},
  {label:'Partners',href:'#partners',children:[{label:'Sponsors',href:'#sponsors'},{label:'Marketing Partners',href:'#marketing-partners'},{label:'Media Partners',href:'#media-partners'}]},
  {label:'Awards',href:'#awards'}
];

/* Exhibitor profile — every supplied string kept verbatim.
   Parent/child grouping follows the order of the supplied list (assumption, flagged). */
const EXHIBITORS = [
  {t:'Process Industries & Engineering',items:['Chemical & Pharma Processing','Process Plants & Equipment','Mechanical and Thermal Processes','EPC','Technology Licensors','Project Management Consultants']},
  {t:'Refining, Chemicals & Petrochemicals',items:['Specialty Chemicals','Chloroalkali','Fertilizers']},
  {t:'Research & Innovation',items:['Biotechnology','Green Chemistry']},
  {t:'Pharma & Biopharma',items:['Pharmaceutical Packaging and Storage','Ingredients','Bulk Drugs','R&D','Warehousing','Cold Chain','Contract Research & Manufacturing']},
  {t:'Clean Energy',items:['Hydrogen','Biofuels','Methanol','Carbon Capture Utilization & Storage','Renewables']},
  {t:'Logistics',items:['Containers','Supply Chain Management','Material Handling','Storage & Warehousing']},
  {t:'Corrosion Control',items:['Materials Technology & Testing','Industrial Coatings','Surface Engineering Solutions','New Metallurgies','Inspection & Monitoring Technologies']},
  {t:'Further exhibitor categories',solo:true,items:['Water & Waste Management','Environmental Technologies','Digital Services','Industrial Automation, Instrumentation and Control','Industrial and Labour Safety','Electrical Equipment','Banking, Finance & Insurance','Laboratory and Analytical Techniques']}
];

/* Visitor profile — the six audiences are supplied; full descriptions were NOT in the content file,
   only their topics. `d` carries just those supplied topics until the full copy is provided. */
const VISITORS = [
  {t:'Chemical Plant Operators & Managers',d:'Plant operations.',img:0},
  {t:'Engineers & Project Consultants',d:'Engineering and EPC.',img:0},
  {t:'Industry Decision-Makers & Executives',d:'Corporate purchasing.',img:1},
  {t:'Researchers & Scientists',d:'R&D.',img:1},
  {t:'STEM Students',d:'The Student Outreach Program.',img:2},
  {t:'International Buyers & Delegates',d:'International delegations from over 50 countries.',img:0}
];

/* Industry segments — all 11 supplied names; logo mapping to the supplied concurrent-expo logos. */
const SEG_LOGO = f => BASE+f;
const SEGMENTS = [
  {n:'EPC',src:SEG_LOGO('Engineering-pocurement-and-construction-world-expo-2028.png')},
  {n:'Specialty Chemicals',src:'https://chemtech-online.com/wp-content/uploads/2026/05/specialty-2026-logo.png'},
  {n:'Refining & Petrochemicals',src:SEG_LOGO('Refining-Petro-chemicals-2028.png')},
  {n:'Industry Automation & Process Control',src:SEG_LOGO('Industry-automation-and-control-world-expo-2028.png')},
  {n:'Wastewater, Recycling & Deep Treatment',src:SEG_LOGO('Water-EX-world-Expo.png')},
  {n:'Biopharma & Biotechnology',src:SEG_LOGO('Bio-Pharma-world-expo-2028.png')},
  {n:'Pumps, Valves, Seals',src:SEG_LOGO('Pumps-Valves-and-fittings-world-expo-2028.png')},
  {n:'Agrochemicals & Fertilizers',src:SEG_LOGO('Agrochemicals-and-fertilizers-innovation-and-RND-world-expo-2028.png')},
  {n:'Health, Safety & Environment',src:SEG_LOGO('Health-Safty-Environment-world-expo-2028.png')},
  {n:'Surface Engineering & Corrosion Control',src:SEG_LOGO('Surface-Engineering-Coating-Corrosion-world-expo-2028.png')},
  {n:'SCALE — Climate Tech Startups',src:'https://chemtech-online.com/wp-content/uploads/2026/04/chemtechlogo-spectrum.png'}
];

const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const $ = (s,c=document)=>c.querySelector(s);
const $$ = (s,c=document)=>[...c.querySelectorAll(s)];
const ICON_CHEV = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg>';
const ICON_ARR = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';
const esc = s => String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

/* ---------- Toast ---------- */
let toastT;
function toast(msg){const t=$('#toast');t.textContent=msg;t.classList.add('show');clearTimeout(toastT);toastT=setTimeout(()=>t.classList.remove('show'),2800)}

/* ---------- Navigation ---------- */
function buildNav(){
  const d=$('#desktopNav'), m=$('#mobileNav');
  NAV.forEach((item,i)=>{
    const li=document.createElement('li');
    if(item.children){
      li.className='has-dd';
      li.innerHTML=`<button class="nav-link" aria-expanded="false" aria-controls="dd${i}">${item.label}${ICON_CHEV}</button>
        <ul class="dropdown" id="dd${i}">${item.children.map(c=>`<li><a href="${c.href}" ${c.cta?`data-cta="${c.cta}"`:''}>${c.label}</a></li>`).join('')}</ul>`;
    } else li.innerHTML=`<a class="nav-link" href="${item.href}">${item.label}</a>`;
    d.appendChild(li);

    const mli=document.createElement('li'); mli.className='mp-item';
    if(item.children){
      mli.innerHTML=`<button class="mp-link" aria-expanded="false" aria-controls="mdd${i}">${item.label}${ICON_CHEV}</button>
        <div class="mp-sub" id="mdd${i}"><ul>${item.children.map(c=>`<li><a href="${c.href}" ${c.cta?`data-cta="${c.cta}"`:''}>${c.label}</a></li>`).join('')}</ul></div>`;
    } else mli.innerHTML=`<a class="mp-link" href="${item.href}">${item.label}</a>`;
    m.appendChild(mli);
  });

  // Desktop dropdown behaviour
  $$('.has-dd').forEach(li=>{
    const btn=$('button',li);
    const open=()=>{closeAll(li);li.classList.add('open');btn.setAttribute('aria-expanded','true')};
    const close=()=>{li.classList.remove('open');btn.setAttribute('aria-expanded','false')};
    let t;
    li.addEventListener('mouseenter',()=>{if(matchMedia('(hover:hover)').matches){clearTimeout(t);open()}});
    li.addEventListener('mouseleave',()=>{if(matchMedia('(hover:hover)').matches){t=setTimeout(close,120)}});
    btn.addEventListener('click',e=>{e.preventDefault();li.classList.contains('open')?close():open()});
    li.addEventListener('focusout',e=>{if(!li.contains(e.relatedTarget))close()});
    li.addEventListener('keydown',e=>{
      const links=$$('.dropdown a',li);
      if(e.key==='Escape'){close();btn.focus()}
      if(e.key==='ArrowDown'){e.preventDefault();if(!li.classList.contains('open'))open();const idx=links.indexOf(document.activeElement);links[(idx+1)%links.length].focus()}
      if(e.key==='ArrowUp'){e.preventDefault();const idx=links.indexOf(document.activeElement);links[(idx-1+links.length)%links.length].focus()}
    });
  });
  function closeAll(except){$$('.has-dd.open').forEach(l=>{if(l!==except){l.classList.remove('open');$('button',l).setAttribute('aria-expanded','false')}})}
  document.addEventListener('click',e=>{if(!e.target.closest('.has-dd'))closeAll()});
  $$('.dropdown a').forEach(a=>a.addEventListener('click',()=>closeAll()));

  // Mobile
  const burger=$('#burger'),panel=$('#mobilePanel');
  const setOpen=o=>{panel.classList.toggle('open',o);burger.setAttribute('aria-expanded',o);document.body.style.overflow=o?'hidden':'';if(o)setTimeout(()=>$('#mpClose').focus(),100);else burger.focus()};
  burger.addEventListener('click',()=>setOpen(true));
  $('#mpClose').addEventListener('click',()=>setOpen(false));
  panel.addEventListener('keydown',e=>{
    if(e.key==='Escape')setOpen(false);
    if(e.key==='Tab'){const f=$$('a,button',panel).filter(x=>x.offsetParent!==null);const first=f[0],last=f[f.length-1];
      if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus()}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus()}}
  });
  $$('button.mp-link',panel).forEach(b=>b.addEventListener('click',()=>{const ex=b.getAttribute('aria-expanded')==='true';b.setAttribute('aria-expanded',!ex);$('#'+b.getAttribute('aria-controls')).classList.toggle('open',!ex)}));
  $$('a',panel).forEach(a=>a.addEventListener('click',()=>{if(a.getAttribute('href')!=='#'||!a.dataset.cta){panel.classList.remove('open');burger.setAttribute('aria-expanded','false');document.body.style.overflow=''}}));
}

/* ---------- Configurable CTAs ---------- */
function wireCTAs(){
  $$('[data-cta]').forEach(a=>{
    const url=SITE_CONFIG[a.dataset.cta];
    if(url){a.href=url;if(/^https?:/.test(url)){a.target='_blank';a.rel='noopener'}}
    else{
      a.setAttribute('href','#');
      a.addEventListener('click',e=>{e.preventDefault();toast('This link will be available soon. Please check back shortly.')});
    }
  });
}

/* ---------- Image fallback ---------- */
function imgFallback(){
  $$('.frame img, .logo-item img, .scale-brand').forEach(img=>{
    const fail=()=>img.closest('.frame, .logo-item')?.classList.add('img-fail');
    if(img.complete&&img.naturalWidth===0&&img.src)fail();
    img.addEventListener('error',fail,{once:true});
  });
}

/* ---------- Logo carousel ---------- */
function buildLogos(){
  const track=$('#logoTrack');
  const make=(l,clone)=>`<div class="logo-item" ${clone?'aria-hidden="true"':''} title="${esc(l.name)}">
    <img src="${l.src}" alt="${clone?'':esc(l.name)+' logo'}" loading="lazy" decoding="async" draggable="false">
    <span class="fallback">${esc(l.name)}</span></div>`;
  track.innerHTML=LOGOS.map(l=>make(l,false)).join('')+LOGOS.map(l=>make(l,true)).join('');

  let paused=reduceMotion, hover=false, drag=false, startX=0, startScroll=0, pos=0, userPaused=reduceMotion;
  const half=()=>track.scrollWidth/2;
  const pauseBtn=$('#logoPause');
  const setIcon=()=>{pauseBtn.setAttribute('aria-pressed',userPaused);pauseBtn.setAttribute('aria-label',userPaused?'Play logo carousel':'Pause logo carousel');
    $('#pauseIco').innerHTML=userPaused?'<path d="M8 5l11 7-11 7z"/>':'<path d="M9 6v12M15 6v12"/>'};
  setIcon();
  function tick(){
    if(!userPaused&&!hover&&!drag&&!document.hidden){
      pos=track.scrollLeft+0.5; if(pos>=half())pos-=half(); track.scrollLeft=pos;
    }
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
  track.addEventListener('mouseenter',()=>hover=true);
  track.addEventListener('mouseleave',()=>{hover=false;drag=false;track.classList.remove('dragging')});
  track.addEventListener('focusin',()=>hover=true);
  track.addEventListener('focusout',()=>hover=false);
  track.addEventListener('touchstart',()=>{hover=true},{passive:true});
  track.addEventListener('touchend',()=>{setTimeout(()=>hover=false,1500)},{passive:true});
  track.addEventListener('scroll',()=>{if(track.scrollLeft>=half())track.scrollLeft-=half();if(track.scrollLeft<=0&&(hover||drag))track.scrollLeft+=half()},{passive:true});
  track.addEventListener('mousedown',e=>{drag=true;startX=e.pageX;startScroll=track.scrollLeft;track.classList.add('dragging')});
  window.addEventListener('mouseup',()=>{drag=false;track.classList.remove('dragging')});
  track.addEventListener('mousemove',e=>{if(!drag)return;e.preventDefault();track.scrollLeft=startScroll-(e.pageX-startX)});
  const step=dir=>{const w=track.querySelector('.logo-item').offsetWidth+18;track.scrollBy({left:dir*w*2,behavior:reduceMotion?'auto':'smooth'})};
  $('#logoPrev').addEventListener('click',()=>{if(track.scrollLeft<300)track.scrollLeft+=half();step(-1)});
  $('#logoNext').addEventListener('click',()=>step(1));
  track.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();step(1)}if(e.key==='ArrowLeft'){e.preventDefault();step(-1)}});
  pauseBtn.addEventListener('click',()=>{userPaused=!userPaused;setIcon()});
}

/* ---------- Exhibitor index ---------- */
function buildExhibitors(){
  const root=$('#exIndex');
  root.innerHTML=EXHIBITORS.map(g=>`<div class="ex-group reveal${g.solo?' solo':''}"><h3>${esc(g.t)}${g.solo?'':`<span>${g.items.length} categories</span>`}</h3>
    <ul class="ex-list">${g.items.map(i=>`<li>${esc(i)}</li>`).join('')}</ul></div>`).join('');
  const input=$('#exFilter');
  input.addEventListener('input',()=>{
    const q=input.value.trim().toLowerCase(); let any=false;
    $$('.ex-group',root).forEach(g=>{
      let hit=false;
      $$('li',g).forEach(li=>{const m=q&&li.textContent.toLowerCase().includes(q);li.classList.toggle('match',!!m);if(m)hit=true});
      if(q&&$('h3',g).textContent.toLowerCase().includes(q))hit=true;
      g.classList.toggle('dim',!!q&&!hit); if(hit||!q)any=true;
    });
    $('#exEmpty').style.display=any?'none':'block';
  });
}

/* ---------- Visitors ---------- */
function buildVisitors(){
  const list=$('#visList'), imgs=$$('#visFrame img');
  list.innerHTML=VISITORS.map((v,i)=>`<li class="vis-item"><button class="vis-btn" aria-expanded="${i===0}" aria-controls="vp${i}" id="vb${i}" data-img="${v.img}">${esc(v.t)}<span class="plus" aria-hidden="true">+</span></button>
    <div class="vis-panel ${i===0?'open':''}" id="vp${i}" role="region" aria-labelledby="vb${i}"><div><p>${esc(v.d)}</p></div></div></li>`).join('');
  $$('.vis-btn',list).forEach(b=>b.addEventListener('click',()=>{
    const isOpen=b.getAttribute('aria-expanded')==='true';
    $$('.vis-btn',list).forEach(x=>{x.setAttribute('aria-expanded','false');$('#'+x.getAttribute('aria-controls')).classList.remove('open')});
    if(!isOpen){b.setAttribute('aria-expanded','true');$('#'+b.getAttribute('aria-controls')).classList.add('open');
      imgs.forEach((im,k)=>im.classList.toggle('on',k==+b.dataset.img))}
  }));
}

/* ---------- Segments ---------- */
function buildSegments(){
  const list=$('#segList');
  list.innerHTML=SEGMENTS.map((s,i)=>`<li class="seg-row" role="presentation"><button class="seg-btn ${i===0?'active':''}" role="tab" aria-selected="${i===0}" aria-controls="segPanel" data-i="${i}" tabindex="${i===0?0:-1}">${esc(s.n)}<span class="arr">${ICON_ARR}</span></button></li>`).join('');
  const logo=$('#segLogo'),name=$('#segName');
  const set=i=>{const s=SEGMENTS[i];logo.src=s.src;logo.alt=s.n+' logo';name.textContent=s.n};
  const show=i=>{
    $$('.seg-btn',list).forEach((b,k)=>{b.classList.toggle('active',k===i);b.setAttribute('aria-selected',k===i);b.tabIndex=k===i?0:-1});
    logo.classList.add('swap');
    setTimeout(()=>{set(i);logo.classList.remove('swap')},reduceMotion?0:180);
  };
  logo.addEventListener('error',()=>{logo.style.visibility='hidden'});
  logo.addEventListener('load',()=>{logo.style.visibility=''});
  set(0);
  $$('.seg-btn',list).forEach(b=>{
    b.addEventListener('click',()=>show(+b.dataset.i));
    b.addEventListener('mouseenter',()=>{if(matchMedia('(hover:hover) and (min-width:981px)').matches)show(+b.dataset.i)});
    b.addEventListener('keydown',e=>{
      const i=+b.dataset.i;let n=null;
      if(e.key==='ArrowDown')n=(i+1)%SEGMENTS.length;if(e.key==='ArrowUp')n=(i-1+SEGMENTS.length)%SEGMENTS.length;
      if(n!==null){e.preventDefault();show(n);$$('.seg-btn',list)[n].focus()}
    });
  });
}

/* ---------- Generic scroller (prev/next, keyboard, end-state) ---------- */
function initScroller(trackSel,prevSel,nextSel){
  const tr=$(trackSel),pv=$(prevSel),nx=$(nextSel);if(!tr)return;
  const step=()=>Math.max(240,tr.clientWidth*.85);
  const upd=()=>{const max=tr.scrollWidth-tr.clientWidth-2;pv.disabled=tr.scrollLeft<=2;nx.disabled=tr.scrollLeft>=max;pv.style.opacity=pv.disabled?.4:1;nx.style.opacity=nx.disabled?.4:1};
  pv.addEventListener('click',()=>tr.scrollBy({left:-step(),behavior:reduceMotion?'auto':'smooth'}));
  nx.addEventListener('click',()=>tr.scrollBy({left:step(),behavior:reduceMotion?'auto':'smooth'}));
  tr.addEventListener('scroll',upd,{passive:true});addEventListener('resize',upd);
  tr.addEventListener('keydown',e=>{if(e.key==='ArrowRight'){e.preventDefault();nx.click()}if(e.key==='ArrowLeft'){e.preventDefault();pv.click()}});
  upd();setTimeout(upd,400);
}

/* ---------- Luminaries ---------- */
function buildLuminaries(){
  const root=$('#lumTrack');
  const skip=/^(dr|mr|shri|prof\.?|\(dr\.\))$/i;
  const mono=n=>{const t=n.split(/\s+/).filter(x=>!skip.test(x));return ((t[0]||'')[0]||'')+((t[t.length-1]||'')[0]||'')};
  root.innerHTML=LUMINARIES.map(p=>`<article class="lum">
    <div class="lum-ph frame" data-alt="${esc(p.name)}">${p.photo?`<img src="${esc(p.photo)}" alt="${esc(p.name)}" loading="lazy">`:`<span class="mono" aria-hidden="true">${esc(mono(p.name))}</span>`}</div>
    <div class="lum-body"><h3>${esc(p.name)}</h3>${p.designation?`<p>${esc(p.designation)}</p>`:''}${p.role?`<span class="lum-role">${esc(p.role)}</span>`:''}</div></article>`).join('');
  initScroller('#lumTrack','#lumPrev','#lumNext');
}

/* ---------- Conferences (expandable captions) ---------- */
function buildConferences(){
  const root=$('#cgTrack');
  root.innerHTML=CONFERENCES.map((c,i)=>`<article class="cg-card">
    <div class="cg-media frame" data-alt="${esc(c.t)}">${c.img?`<img src="${esc(c.img)}" alt="${esc(c.alt||c.t)}" loading="lazy">`:`<span class="cg-tag" aria-hidden="true">${esc(c.tag)}</span>`}</div>
    <div class="cg-body"><span class="cg-date">2026 Inaugural Session${c.date?` · ${esc(c.date)}`:''}</span><h3>${esc(c.t)}</h3>
    ${c.caption?`<p class="cg-cap" id="cap${i}">${esc(c.caption)}</p><button class="more-btn" type="button" aria-expanded="false" aria-controls="cap${i}" data-cap="cap${i}"><span>Read full caption</span><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" aria-hidden="true"><path d="M6 9l6 6 6-6"/></svg></button>`:''}
    </div></article>`).join('');
  $$('[data-cap]',root).forEach(b=>b.addEventListener('click',()=>{
    const p=$('#'+b.dataset.cap),o=b.getAttribute('aria-expanded')!=='true';
    p.classList.toggle('open',o);b.setAttribute('aria-expanded',o);$('span',b).textContent=o?'Show less':'Read full caption';
  }));
  initScroller('#cgTrack','#cgPrev','#cgNext');
}

/* ---------- Pavilions ---------- */
function buildPavilions(){
  $('#international').innerHTML=PAVILIONS.map((p,i)=>`<article class="pav reveal${i?` reveal-d${i}`:''}">
    <div class="frame zoom" data-alt="${esc(p.t)}">${p.img?`<img src="${esc(p.img)}" alt="${esc(p.t)}" loading="lazy">`:''}</div>
    <div class="pav-body"><div class="pav-flag" aria-hidden="true">${p.flag.map(c=>`<i style="background:${c};${c==='#ffffff'?'border-top:1px solid #e3e8ef;border-bottom:1px solid #e3e8ef':''}"></i>`).join('')}</div>
    <h3>${esc(p.t)}</h3></div></article>`).join('');
}

/* ---------- Testimonials ---------- */
function buildTestimonials(){
  const root=$('#testiRoot');
  if(!TESTIMONIALS.length){
    root.innerHTML=`<div class="testi-empty"><div class="testi-quote-mark" aria-hidden="true">“</div><p>Testimonials from CHEMTECH exhibitors, delegates and partners will appear here.</p></div>`;
    return;
  }
  root.innerHTML=`<div class="testi-stage" role="region" aria-roledescription="carousel" aria-label="Testimonials">
    <div class="testi-quote-mark" aria-hidden="true">“</div>
    <div class="testi-viewport"><div class="testi-track" id="tTrack">${TESTIMONIALS.map((t,i)=>`<figure class="testi-slide" role="group" aria-roledescription="slide" aria-label="${i+1} of ${TESTIMONIALS.length}" style="margin:0">
      <blockquote>${esc(t.quote)}</blockquote><figcaption><b>${esc(t.name)}</b><span>${[t.designation,t.organisation].filter(Boolean).map(esc).join(', ')}</span></figcaption></figure>`).join('')}</div></div>
    <div class="testi-nav"><button class="ctrl-btn" id="tPrev" aria-label="Previous testimonial"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 6l-6 6 6 6"/></svg></button>
    <span class="testi-count" id="tCount" aria-live="polite"></span>
    <button class="ctrl-btn" id="tNext" aria-label="Next testimonial"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M9 6l6 6-6 6"/></svg></button></div></div>`;
  let i=0;const n=TESTIMONIALS.length,tr=$('#tTrack');
  const go=k=>{i=(k+n)%n;tr.style.transform=`translateX(-${i*100}%)`;$('#tCount').textContent=`${i+1} / ${n}`;$$('.testi-slide',tr).forEach((s,j)=>s.setAttribute('aria-hidden',j!==i))};
  $('#tPrev').onclick=()=>go(i-1);$('#tNext').onclick=()=>go(i+1);go(0);
  let sx=null;tr.addEventListener('touchstart',e=>sx=e.touches[0].clientX,{passive:true});
  tr.addEventListener('touchend',e=>{if(sx===null)return;const dx=e.changedTouches[0].clientX-sx;if(Math.abs(dx)>40)go(i+(dx<0?1:-1));sx=null});
}

/* ---------- Journey (alternating cinematic timeline) ---------- */
function buildJourney(){
  const ol=$('#jr2');
  ol.innerHTML=JOURNEY.map((m,k)=>`<li class="jr2-item ${k%2?'r':'l'}${m.gold?' gold':''} reveal" id="j${esc(m.year)}">
    <span class="jr2-dot" aria-hidden="true"></span>
    <div class="jr2-card">
      ${m.gold?'<span class="jr2-badge">Golden Jubilee</span>':''}
      <div class="jr2-year" aria-hidden="true">${esc(m.year)}</div>
      <h3><span class="sr-only">${esc(m.year)}: </span>${esc(m.title)}</h3>
      <p>${esc(m.text)}</p>
      ${m.image?`<div class="frame zoom" data-alt="${esc(m.imageAlt||m.title)}"><img src="${esc(m.image)}" alt="${esc(m.imageAlt||m.title)}" loading="lazy"></div>`:''}
    </div></li>`).join('');
  const wrap=$('#jr2Wrap'),fill=$('#jr2Fill'),items=$$('.jr2-item',ol);
  let tick=false;
  const upd=()=>{
    const r=wrap.getBoundingClientRect(),mid=innerHeight*.55;
    const f=Math.min(1,Math.max(0,(mid-r.top)/r.height));
    fill.style.height=(f*100).toFixed(2)+'%';
    items.forEach(it=>{const d=$('.jr2-dot',it).getBoundingClientRect();it.classList.toggle('active',d.top<mid)});
    tick=false;
  };
  addEventListener('scroll',()=>{if(!tick){tick=true;requestAnimationFrame(upd)}},{passive:true});
  addEventListener('resize',upd);upd();
}

/* ---------- Footer contact ---------- */
function buildFooter(){
  const c=SITE_CONFIG.contact,ul=$('#ftContact'),ad=$('#ftAddress');
  if(c.address)ad.textContent=c.address;
  else ad.textContent='Postal address, phone and email will be published here.';
  if(c.phone)ul.innerHTML+=`<li><a href="tel:${esc(c.phone.replace(/\s/g,''))}">${esc(c.phone)}</a></li>`;
  if(c.email)ul.innerHTML+=`<li><a href="mailto:${esc(c.email)}">${esc(c.email)}</a></li>`;
  $('#yr').textContent=new Date().getFullYear();
}

/* ---------- Read-more toggles ---------- */
function initMore(){
  $$('[data-more]').forEach(b=>b.addEventListener('click',()=>{
    const body=$('#'+b.dataset.more),o=b.getAttribute('aria-expanded')!=='true';
    body.classList.toggle('open',o);b.setAttribute('aria-expanded',o);$('span',b).textContent=o?'Show less':'Read more';
  }));
}

/* ---------- Highlight icons ---------- */
function metricIcons(){
  const I=[
    '<circle cx="9" cy="8" r="3.2"/><path d="M3 20c0-3.3 2.7-6 6-6s6 2.7 6 6M16 5.5a3 3 0 0 1 0 5.6M18 14.5c2 .7 3.5 2.6 3.5 5.5"/>',
    '<path d="M3 21V8l7 4V8l7 4V4h4v17zM7 21v-4M12 21v-4"/>',
    '<rect x="4" y="3" width="16" height="12" rx="2"/><path d="M8 20h8M12 15v5M8 8h8M8 11h5"/>',
    '<rect x="3" y="7" width="18" height="13" rx="2"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18"/>',
    '<path d="M12 3a3 3 0 0 0-3 3v5a3 3 0 0 0 6 0V6a3 3 0 0 0-3-3zM6 11a6 6 0 0 0 12 0M12 17v4M9 21h6"/>',
    '<path d="M12 21v-8M12 13c0-4-3-6-7-6 0 4 3 6 7 6zM12 15c0-3 2-5 6-5 0 3-2 5-6 5z"/>',
    '<path d="M2 9l10-5 10 5-10 5zM6 11.5V16c0 1.4 2.7 3 6 3s6-1.6 6-3v-4.5"/>'
  ];
  $$('.metric').forEach((m,i)=>{const s=document.createElement('span');s.className='m-ico';s.setAttribute('aria-hidden','true');
    s.innerHTML=`<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${I[i]||''}</svg>`;m.prepend(s)});
}

/* ---------- Countdown ---------- */
function countdown(){
  const target=new Date('2028-03-14T10:00:00+05:30').getTime();
  const el={d:$('[data-cd=d]'),h:$('[data-cd=h]'),m:$('[data-cd=m]'),s:$('[data-cd=s]')};
  const pad=n=>String(n).padStart(2,'0');
  const run=()=>{let t=Math.max(0,target-Date.now());
    el.d.textContent=Math.floor(t/864e5);el.h.textContent=pad(Math.floor(t%864e5/36e5));el.m.textContent=pad(Math.floor(t%36e5/6e4));el.s.textContent=pad(Math.floor(t%6e4/1e3))};
  run();setInterval(run,1000);
}

/* ---------- Reveal & count-up ---------- */
function observers(){
  const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in');io.unobserve(e.target)}}),{threshold:.12,rootMargin:'0px 0px -40px 0px'});
  $$('.reveal').forEach(el=>reduceMotion?el.classList.add('in'):io.observe(el));
  /* clip-reveal elements are fully clipped, so the browser reports them as never intersecting — observe their parents instead */
  const kids=new Map();
  const pio=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting){(kids.get(e.target)||[]).forEach(k=>k.classList.add('in'));pio.unobserve(e.target)}}),{threshold:.1,rootMargin:'0px 0px -40px 0px'});
  $$('.clip-reveal').forEach(el=>{if(reduceMotion){el.classList.add('in');return}const p=el.parentElement;kids.set(p,(kids.get(p)||[]).concat(el));pio.observe(p)});
  
  const fmt=n=>n.toLocaleString('en-US');
  const cio=new IntersectionObserver(es=>es.forEach(e=>{
    if(!e.isIntersecting)return;cio.unobserve(e.target);
    const el=e.target,end=+el.dataset.count;
    if(reduceMotion){el.textContent=fmt(end);return}
    const dur=1800,st=performance.now();
    const step=now=>{const p=Math.min(1,(now-st)/dur),v=Math.round(end*(1-Math.pow(1-p,4)));el.textContent=fmt(v);if(p<1)requestAnimationFrame(step)};
    requestAnimationFrame(step);
  }),{threshold:.4});
  $$('[data-count]').forEach(el=>{el.textContent=reduceMotion?fmt(+el.dataset.count):'0';cio.observe(el)});
}

/* ---------- Scroll: header, parallax, to-top ---------- */
function scrollFx(){
  const header=$('#siteHeader'),top=$('#toTop'),par=$$('[data-parallax]');
  let ticking=false;
  const update=()=>{
    const y=scrollY;
    header.classList.toggle('scrolled',y>10);
    top.classList.toggle('show',y>900);
    if(!reduceMotion)par.forEach(el=>{
      const r=el.getBoundingClientRect();if(r.bottom<0||r.top>innerHeight)return;
      const c=(r.top+r.height/2-innerHeight/2)*+el.dataset.parallax;
      const img=el.querySelector('img');if(img)img.style.translate=`0 ${c.toFixed(1)}px`;
    });
    ticking=false;
  };
  addEventListener('scroll',()=>{if(!ticking){requestAnimationFrame(update);ticking=true}},{passive:true});
  update();
  top.addEventListener('click',()=>scrollTo({top:0,behavior:reduceMotion?'auto':'smooth'}));
}

/* ---------- Init ---------- */
buildNav();
buildLogos();
buildExhibitors();
buildVisitors();
buildSegments();
buildLuminaries();
buildConferences();
buildPavilions();
buildTestimonials();
buildJourney();
buildFooter();
initMore();
metricIcons();
wireCTAs();
imgFallback();
countdown();
$('#heroBanner').src=SITE_CONFIG.heroBanner;$('#heroSecond').src=SITE_CONFIG.heroSecond;
observers();
scrollFx();
requestAnimationFrame(()=>setTimeout(()=>$('.hero').classList.add('loaded'),60));
