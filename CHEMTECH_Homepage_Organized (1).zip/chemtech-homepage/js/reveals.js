(function() {
    function triggerReveals() {
        document.querySelectorAll('.reveal,.clip-reveal').forEach(function(el) {
            var rect = el.getBoundingClientRect();
            if (rect.top < window.innerHeight && rect.bottom > 0) {
                el.classList.add('in', 'is-visible');
            }
        });
    }
    // Trigger on load and after a short delay to catch timing issues
    if (document.readyState === 'complete') {
        triggerReveals();
        setTimeout(triggerReveals, 100);
    } else {
        window.addEventListener('load', function() {
            triggerReveals();
            setTimeout(triggerReveals, 100);
        });
    }
})();
